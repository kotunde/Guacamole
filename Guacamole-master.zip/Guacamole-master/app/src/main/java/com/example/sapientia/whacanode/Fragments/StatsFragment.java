package com.example.sapientia.whacanode.Fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.sapientia.whacanode.Helpers.StatAdapter;
import com.example.sapientia.whacanode.MainActivity;
import com.example.sapientia.whacanode.Models.Statistic;
import com.example.sapientia.whacanode.R;

import java.util.ArrayList;

public class StatsFragment extends Fragment {


    private ListView statsListView;
    private StatAdapter statAdapter;
    private ArrayList<Statistic> statistics;

    public StatsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Statistics");
        View view = inflater.inflate(R.layout.fragment_stats, container, false);
        statsListView = view.findViewById(R.id.stat_list);
        statistics = ((MainActivity)getActivity()).getStats();
        statAdapter = new StatAdapter(getContext(), statistics);
        statsListView.setAdapter(statAdapter);
        statAdapter.notifyDataSetChanged();

        return view;
    }

}
