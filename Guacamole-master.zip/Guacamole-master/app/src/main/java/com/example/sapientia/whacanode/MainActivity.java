package com.example.sapientia.whacanode;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;

import com.example.sapientia.whacanode.Fragments.CreateSequenceFragment;
import com.example.sapientia.whacanode.Fragments.SequenceFragment;
import com.example.sapientia.whacanode.Fragments.SequenceListFragment;
import com.example.sapientia.whacanode.Fragments.StatsFragment;
import com.example.sapientia.whacanode.Models.Exercise;
import com.example.sapientia.whacanode.Models.Statistic;
import com.example.sapientia.whacanode.ServerRelated.NodeClient;

import java.util.ArrayList;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivity extends AppCompatActivity{

    private ServerSocket serverSocket;
    private Thread thread;
    private ArrayList<NodeClient> nodes =  new ArrayList<>();
    private ArrayList<Exercise> exercises = new ArrayList<>();
    private ArrayList<Statistic> statistics = new ArrayList<>();

    public MainActivity() {
        initServer();
    }

    private void initServer() {
        try {
            serverSocket = new ServerSocket(13000);
        } catch (IOException e){
            Log.d("SERVER", e.getMessage());
        }

        Log.d("SERVER", "Server Started!");

        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!serverSocket.isClosed()) {
                    try {
                        Socket clientSocket = serverSocket.accept();
                        Log.d("SERVER", "Node Connected");
                        nodes.add(new NodeClient(clientSocket));
                    } catch (IOException e) {
                        Log.d("SERVER", e.getMessage());
                    }
                }
            }
        });
        thread.start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_placeholder, new SequenceListFragment());
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.playlist:
                        changeFragment(new SequenceListFragment(), null);
                        return true;
                    case R.id.newSequence:
                        changeFragment(new CreateSequenceFragment(), null);
                        return true;
                    case R.id.stats:
                        changeFragment(new StatsFragment(), null);
                }
                return false;
            }
        });

    }

    public void changeFragment(Fragment fragment, Bundle bundle) {
        if(bundle != null){
            fragment.setArguments(bundle);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_placeholder, fragment).commit();
    }

    public ArrayList<NodeClient> getNodes() {
        return nodes;
    }


    public ArrayList<Exercise> getExercises() {
        //TODO extend this function later
        return exercises;
    }

    public ArrayList<Statistic> getStats() {
        //TODO extend this function later
        return statistics;
    }

    public void saveExercise(Exercise exercise) {
        exercises.add(exercise);
        changeFragment(new SequenceListFragment(), null);
    }

    public void saveStatistic(Statistic statistic) {
        statistics.add(statistic);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        nodes.clear();
    }
}
