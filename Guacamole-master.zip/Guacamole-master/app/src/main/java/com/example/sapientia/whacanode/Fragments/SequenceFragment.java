package com.example.sapientia.whacanode.Fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Switch;

import com.example.sapientia.whacanode.Helpers.PositionAdapter;
import com.example.sapientia.whacanode.MainActivity;
import com.example.sapientia.whacanode.Models.Exercise;
import com.example.sapientia.whacanode.Models.Position;
import com.example.sapientia.whacanode.Models.Statistic;
import com.example.sapientia.whacanode.R;
import com.example.sapientia.whacanode.ServerRelated.NodeClient;
import com.example.sapientia.whacanode.ServerRelated.NodeMessageHandler;

import java.util.ArrayList;
import java.util.Random;

public class SequenceFragment extends Fragment implements NodeMessageHandler {

    private Exercise exercise;
    private Statistic statistic;
    private String playerName;

    private ArrayList<Position> positions = new ArrayList<>();
    private ArrayList<NodeClient> nodes;

    private PositionAdapter positionAdapter;

    private GridView positionListView;
    private Button startButton;

    private int currentSequenceIndex = 0;
    private boolean isSequencePlaying = false;
    private int repeat;
    private boolean isRandom;
    private Random randomGen;
    private boolean nameEntered = false;


    public SequenceFragment(){
    }

    @SuppressLint("ValidFragment")
    public SequenceFragment(Exercise exercise){
        this.exercise = exercise;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (exercise == null) {
            Log.d("ittne", exercise.name);
        }

        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(exercise.name);

        nodes = ((MainActivity) getActivity()).getNodes();
        repeat = exercise.repeat * exercise.sequence.size();
        randomGen = new Random();

        initPositions();

        Log.d("EXERCISE", exercise.toString());
    }

    private void initPositions() {
        for (int i = 0; i < 16; i++) {
            positions.add(new Position());
        }

        for (int i = 0; i < exercise.sequence.size(); i++) {
            positions.get(exercise.sequence.get(i)).setSequenceNumber(i + 1);
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        if (!nameEntered) {
            nameEntered = true;

            final View nameDialog = getLayoutInflater().inflate(R.layout.player_name_dialog, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setView(nameDialog);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    EditText inputField = nameDialog.findViewById(R.id.player_name);
                    playerName = inputField.getText().toString();
                }
            });

            builder.show();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_sequence, container, false);
        initView(view);

        return view;
    }

    private void initView(View view){
        positionAdapter = new PositionAdapter(view.getContext(), positions);
        positionListView = view.findViewById(R.id.grid);
        positionListView.setAdapter(positionAdapter);

        initPositionViews();

        startButton = view.findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSequence();
            }
        });
        startButton.setVisibility(View.VISIBLE);

        ((Switch) view.findViewById(R.id.switch_random)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isRandom = isChecked;
            }
        });
    }

    private void initPositionViews(){
        positionListView.post(new Runnable() {
            @Override
            public void run() {
                for(int i = 0; i < exercise.sequence.size(); ++i){
                    final Position p  = positions.get(exercise.sequence.get(i));
                    View child = positionListView.getChildAt(exercise.sequence.get(i));

                    final Button positionButton = child.findViewById(R.id.positionButton);
                    positionButton.setVisibility(View.VISIBLE);
                    positionButton.setText(String.valueOf(i+1));
                    positionButton.setBackgroundResource(R.drawable.position_filled_background);
                    positionButton.setTextColor(getResources().getColor(R.color.white));
                    positionButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String[] nodeNames = new String[nodes.size()];
                            for (int i = 0; i < nodes.size(); i++) {
                                nodeNames[i] = nodes.get(i).getId();
                            }

                            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                            builder.setTitle("Pick a Node");
                            builder.setItems(nodeNames, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    NodeClient node = nodes.get(which);
                                    if (!node.hasHandler()) {
                                        node.setMessageHandler(SequenceFragment.this);
                                    }
                                    for (int i = 0; i < 16; i++) {
                                        if (positions.get(i).getAssignedNode() == node) {
                                            positions.get(i).setAssignedNode(null);
                                        }
                                    }
                                    p.setAssignedNode(node);
                                    positionAdapter.notifyDataSetChanged();
                                }
                            });
                            builder.show();
                        }
                    });
                }
            }
        });
    }

    public void handleMessage(NodeClient from, String message) {
        Log.d("SEQUENCE", from.getId() + ": " + message);
        String splitted[] = message.split(",");

        if (splitted[0].equals(NodeClient.RECIEVABLES.OFF.toString()))
        {
            deleteNode(from);
        }
        if (splitted[0].equals(NodeClient.RECIEVABLES.STARTED.toString())) {
            // TODO ui
            ledOFF();
            if (isSequencePlaying) {
                next();
            }
        }
        if (splitted[0].equals(NodeClient.RECIEVABLES.MEASURED.toString())) {
            // TODO ui

            statistic.addReaction(Double.parseDouble(splitted[1]));
            if (isSequencePlaying) {
                next();
            } else {
                resetStartButton();
            }
        }
        if (splitted[0].equals(NodeClient.RECIEVABLES.WARNING.toString())) {
            if (isSequencePlaying) {
                statistic.addReaction(-1);
                // TODO ui
            }
        }
    }

    private void ledOFF(){
        for (int i = 0; i < exercise.sequence.size(); i++) {
            NodeClient node = positions.get(exercise.sequence.get(i)).getAssignedNode();
            if (node != null) {
                node.send(NodeClient.SENDABLES.LEDOFF.toString());
            }
        }
    }

    private void startSequence() {
        statistic = new Statistic();
        int count = 0;

        for (int i = 0; i < exercise.sequence.size(); i++) {
            NodeClient node = positions.get(exercise.sequence.get(i)).getAssignedNode();
            if (node != null) {
                node.send(NodeClient.SENDABLES.WAIT.toString());
                count++;
            }
        }
        if (count != 0) {
            isSequencePlaying = true;
            startButton.setEnabled(false);
            Log.d("EXERCISE", "EXERCISE STARTED");
        }
    }

    private void resetExercise() {
        isSequencePlaying = false;
        repeat = exercise.repeat * exercise.sequence.size();
        currentSequenceIndex = 0;

        statistic.exerciseName = exercise.name;
        statistic.playerName = playerName;

        ((MainActivity) getActivity()).saveStatistic(statistic);
    }

    private void resetStartButton() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                startButton.setEnabled(true);
            }
        });

        for (int i = 0; i < exercise.sequence.size(); i++) {
            NodeClient node = positions.get(exercise.sequence.get(i)).getAssignedNode();
            if (node != null) {
                node.send(NodeClient.SENDABLES.WAIT.toString());
            }
        }
    }

    private void next() {
        NodeClient node;

        int p;
        do {
            node = null;
            while (node == null) {
                node = positions.get(exercise.sequence.get(currentSequenceIndex)).getAssignedNode();

                if (isRandom) {
                    currentSequenceIndex = randomGen.nextInt(exercise.sequence.size());
                } else {
                    currentSequenceIndex++;

                    if (currentSequenceIndex == exercise.sequence.size()) {
                        currentSequenceIndex = 0;
                    }
                }
            }
            p = randomGen.nextInt(100);
        } while (p > exercise.probability * 100);

        try {
            Thread.sleep((long) exercise.delay * 1000);
        } catch (Exception e) {
            //TODO handle this exception properly
        }

        node.send(NodeClient.SENDABLES.MEASURE.toString());
        Log.d("SEQUENCE",  node.getId());
        repeat--;
        if (repeat == 0) {
            resetExercise();
        }
    }

    private void deleteNode(NodeClient node) {
        while(nodes.contains(node)) {
            nodes.remove(node);
        }

        for (int i = 0; i < 16; i++) {
            if (node == positions.get(i).getAssignedNode()) {
                positions.get(i).setAssignedNode(null);
            }
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                positionAdapter.notifyDataSetChanged();
            }
        });

        if (isSequencePlaying) {
            ledOFF();
            next();
        }
    }
}
