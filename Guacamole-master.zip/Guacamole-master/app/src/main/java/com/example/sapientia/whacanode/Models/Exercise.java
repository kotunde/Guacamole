package com.example.sapientia.whacanode.Models;

import java.util.ArrayList;

public class Exercise {
    public ArrayList<Integer> sequence = new ArrayList<>();
    public int repeat = 3;
    public double delay = 1;
    public double probability = 0.75;
    public String name = "";
}