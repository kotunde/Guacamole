package com.example.sapientia.whacanode.ServerRelated;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class NodeClient {

    public enum SENDABLES {
        MEASURE, WAIT, LEDOFF
    }

    public enum RECIEVABLES {

        CONNECTED, MEASURED, WARNING, STARTED, OFF, ON
    }

    private String id;
    private String battery;


    private Socket socket;

    private PrintWriter out;
    private BufferedReader in;

    NodeMessageHandler handler;

    public NodeClient(final Socket socket) {

        this.socket = socket;

        try {

            socket.setSoTimeout(2000);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            //TODO
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                String inputLine;

                while (true) {

                    try {
                        inputLine = in.readLine();
                    } catch (IOException e) {
                        break;
                    }

                    handleMessage(inputLine);
                }

                try {
                    socket.close();
                } catch (Exception e) {
                    Log.e("NODE", "Could not close socket: " + e.getMessage());
                }

                handleMessage(RECIEVABLES.OFF.toString());
            }
        }).start();
    }

    public void setMessageHandler(NodeMessageHandler handler) {
        this.handler = handler;
    }

    private void handleMessage(String message) {
        String splitted[] = message.split(",");

        switch (splitted[0]) {
            case "CONNECTED":
                id = splitted[1];
                break;
            case "ON":
                battery = splitted[1];
                break;
            default:
                if (handler != null)
                {
                    handler.handleMessage(this, message);
                }
        }
    }

    public void send(final String message) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                out.println(message);
            }
        }).start();
    }

    public boolean hasHandler() {
        return (handler != null);
    }

    public String getId() {
        return id;
    }
}
