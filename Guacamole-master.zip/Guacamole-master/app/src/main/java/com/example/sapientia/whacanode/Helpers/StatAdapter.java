package com.example.sapientia.whacanode.Helpers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sapientia.whacanode.Models.Statistic;
import com.example.sapientia.whacanode.R;

import java.util.ArrayList;

public class StatAdapter extends ArrayAdapter<Statistic> {

    private class StatViewHolder {
        TextView playerName;
        TextView exerciseName;
        TextView nrOfMistakes;
        TextView avarageReactionTime;
        TextView slowest;
        TextView fastest;
    }

    public StatAdapter(Context context, ArrayList<Statistic> statistics) {
        super(context, R.layout.stat, statistics);
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        final Statistic current = getItem(position);
        StatAdapter.StatViewHolder statViewHolder;

        if (convertView == null) {
            statViewHolder = new StatAdapter.StatViewHolder();

            convertView = LayoutInflater.from(getContext()).inflate(R.layout.stat, parent, false);
            convertView.setTag(statViewHolder);

            statViewHolder.playerName = convertView.findViewById(R.id.player_name);
            statViewHolder.exerciseName = convertView.findViewById(R.id.exercise_name);
            statViewHolder.nrOfMistakes = convertView.findViewById(R.id.nr_mistakes);
            statViewHolder.avarageReactionTime = convertView.findViewById(R.id.avg_reaction);
            statViewHolder.slowest = convertView.findViewById(R.id.slowest);
            statViewHolder.fastest = convertView.findViewById(R.id.fastest);

            statViewHolder.playerName.setText("Player: " + current.playerName);
            statViewHolder.exerciseName.setText("Exercise: " + current.exerciseName);
            statViewHolder.avarageReactionTime.setText("Avarage reaction: " + current.getReaction_avarage() + " ms");
            statViewHolder.nrOfMistakes.setText("Nr. of mistakes: " + current.getMistakes());
            statViewHolder.slowest.setText("Fastest: " + current.getReaction_min());
            statViewHolder.fastest.setText("Slowest: " + current.getReaction_max());
        } else {
            statViewHolder = (StatAdapter.StatViewHolder) convertView.getTag();
            statViewHolder.playerName.setText("Player: " + current.playerName);
            statViewHolder.exerciseName.setText("Exercise: " + current.exerciseName);
            statViewHolder.avarageReactionTime.setText("Avarage reaction: " + current.getReaction_avarage() + " ms");
            statViewHolder.nrOfMistakes.setText("Nr. of mistakes: " + current.getMistakes());
            statViewHolder.slowest.setText("Fastest: " + current.getReaction_min());
            statViewHolder.fastest.setText("Slowest11: " + current.getReaction_max());
        }

        return convertView;
    }

    public static String doublePrecision(double amt, int precision){
        return String.format("%." + precision + "f", amt);
    }
}
