package com.example.sapientia.whacanode.Helpers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sapientia.whacanode.Models.Exercise;
import com.example.sapientia.whacanode.R;

import java.util.ArrayList;

public class SequenceAdapter extends ArrayAdapter<Exercise> {

    private class SequenceViewHolder {
        TextView sequenceName;
        TextView sequenceLength;
    }

    public SequenceAdapter(Context context, ArrayList<Exercise> exercises) {
        super(context, R.layout.sequence_list_element, exercises);
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        final Exercise currentSequence = getItem(position);
        SequenceViewHolder positionViewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.sequence_list_element, parent, false);
            positionViewHolder = new SequenceViewHolder();
            positionViewHolder.sequenceName = convertView.findViewById(R.id.sequence_name);
            positionViewHolder.sequenceLength = convertView.findViewById(R.id.sequence_length);
            convertView.setTag(positionViewHolder);
        }

            positionViewHolder = (SequenceViewHolder) convertView.getTag();
            positionViewHolder.sequenceName.setText(currentSequence.name);
            positionViewHolder.sequenceLength.setText("("+ currentSequence.sequence.size() + ")");


        return convertView;
    }
}
