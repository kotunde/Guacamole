package com.example.sapientia.whacanode.Models;

import com.example.sapientia.whacanode.ServerRelated.NodeClient;

public class Position{
    private int sequenceNumber;
    private String nodeName;
    private NodeClient assignedNode;

    public Position(int sequenceNumber){
        this.sequenceNumber = sequenceNumber;
    }

    public Position(){
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName (String nodeName) {
        this.nodeName = nodeName;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public NodeClient getAssignedNode() {
        return assignedNode;
    }

    public void setAssignedNode(NodeClient assignedNode) {
        this.assignedNode = assignedNode;
    }
}