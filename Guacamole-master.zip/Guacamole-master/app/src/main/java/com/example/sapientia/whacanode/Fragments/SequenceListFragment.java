package com.example.sapientia.whacanode.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.sapientia.whacanode.Helpers.SequenceAdapter;
import com.example.sapientia.whacanode.MainActivity;
import com.example.sapientia.whacanode.Models.Exercise;
import com.example.sapientia.whacanode.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class SequenceListFragment extends Fragment {


    private ListView sequenceListView;
    private SequenceAdapter sequenceAdapter;
    private ArrayList<Exercise> exercises;
    public SequenceListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Exercises");
        View view = inflater.inflate(R.layout.fragment_sequence_list, container, false);
        sequenceListView = view.findViewById(R.id.sequence_list_view);
        exercises = ((MainActivity)getActivity()).getExercises();
        sequenceAdapter = new SequenceAdapter(getContext(), exercises);
        sequenceListView.setAdapter(sequenceAdapter);
        sequenceAdapter.notifyDataSetChanged();
        sequenceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ((MainActivity)getActivity()).changeFragment(new SequenceFragment(exercises.get(position)), null);
            }
        });
        // Inflate the layout for this fragment
        return view;
    }

}
