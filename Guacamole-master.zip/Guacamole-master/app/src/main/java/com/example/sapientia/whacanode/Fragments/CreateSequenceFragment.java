package com.example.sapientia.whacanode.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import com.example.sapientia.whacanode.Helpers.PositionAdapter;
import com.example.sapientia.whacanode.Helpers.StatAdapter;
import com.example.sapientia.whacanode.MainActivity;
import com.example.sapientia.whacanode.Models.Position;
import com.example.sapientia.whacanode.Models.Exercise;
import com.example.sapientia.whacanode.R;

import java.util.ArrayList;

public class CreateSequenceFragment extends Fragment {

    private GridView positionListView;
    private FloatingActionButton applyButton;
    private ArrayList<Position> positions = new ArrayList<>();
    private PositionAdapter positionAdapter;
    private Exercise exercise = new Exercise();

    private boolean positionsCleared = false;
    private int sequenceCounter = 0;

    public CreateSequenceFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initPositions();
    }

    private void initPositions() {
        for (int i = 0; i < 16; i++) {
            positions.add(new Position());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_create_sequence, container, false);
        initView(view);

        return view;
    }

    private void initView(View view){
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Create new sequence");
        positionAdapter = new PositionAdapter(view.getContext(), positions);
        positionListView = view.findViewById(R.id.grid);
        positionListView.setAdapter(positionAdapter);
        initPositionViews();

        applyButton = view.findViewById(R.id.apply);
        applyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final View mView = getLayoutInflater().inflate(R.layout.save_sequence_dialog, null);
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setView(mView);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        EditText inputField = mView.findViewById(R.id.sequence_name);
                        exercise.name = inputField.getText().toString();


                        ((MainActivity) getActivity()).saveExercise(exercise);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        final TextView text_repeat = view.findViewById(R.id.repeat);
        text_repeat.setText(Integer.toString(exercise.repeat));
        final TextView text_delay = view.findViewById(R.id.delay);
        text_delay.setText(Double.toString(exercise.delay));
        final TextView text_probability = view.findViewById(R.id.probability);
        text_probability.setText(Double.toString(exercise.probability));

        view.findViewById(R.id.repeat_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (exercise.repeat > 0) {
                    text_repeat.setText(Integer.toString(--exercise.repeat));
                }
            }
        });
        view.findViewById(R.id.repeat_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_repeat.setText(Integer.toString(++exercise.repeat));
            }
        });
        view.findViewById(R.id.delay_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (exercise.delay > 0) {
                    text_delay.setText(StatAdapter.doublePrecision(exercise.delay -= 0.1, 1));
                }
            }
        });
        view.findViewById(R.id.delay_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_delay.setText(StatAdapter.doublePrecision(exercise.delay += 0.1, 1));
            }
        });
        view.findViewById(R.id.probability_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (exercise.probability > 0) {
                    text_probability.setText(StatAdapter.doublePrecision(exercise.probability -= 0.05, 2));
                }
            }
        });
        view.findViewById(R.id.probability_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (exercise.probability < 1) {
                    text_probability.setText(StatAdapter.doublePrecision(exercise.probability += 0.05, 2));
                }
            }
        });
    }

    private void initPositionViews(){
        positionListView.post(new Runnable() {
            @Override
            public void run() {
                for(int i=0; i<16; ++i){
                    final int i_copy = i;

                    View child = positionListView.getChildAt(i);

                    final Button positionButton = child.findViewById(R.id.positionButton);
                    positionButton.setVisibility(View.VISIBLE);
                    positionButton.setText("" + (i + 1) + "");
                    positionButton.setBackgroundResource(R.drawable.position_empty_background);
                    positionButton.setTextColor(getResources().getColor(R.color.black));
                    positionButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!positionsCleared){
                                positionsCleared = true;
                                clearPositionViewTexts();
                            }

                            positionButton.setText("" + ++sequenceCounter);
                            positionButton.setTextColor(getResources().getColor(R.color.white));
                            positionButton.setBackgroundResource(R.drawable.position_filled_background);
                            positionButton.setEnabled(false);

                            exercise.sequence.add(i_copy);
                        }
                    });
                }
            }
        });
    }

    private void clearPositionViewTexts()
    {
        for(int i=0; i<16; ++i){
            View child = positionListView.getChildAt(i);
            Button positionButton = child.findViewById(R.id.positionButton);
            positionButton.setText("");
        }

        View applyView = applyButton;
        applyView.setVisibility(View.VISIBLE);
    }
}