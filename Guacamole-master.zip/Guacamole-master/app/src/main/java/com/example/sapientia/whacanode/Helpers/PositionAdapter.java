package com.example.sapientia.whacanode.Helpers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.example.sapientia.whacanode.Models.Position;
import com.example.sapientia.whacanode.R;
import com.example.sapientia.whacanode.ServerRelated.NodeClient;

import java.util.ArrayList;

public class PositionAdapter extends ArrayAdapter<Position> {

    private class PositionViewHolder {
        Button positionButton;
    }

    public PositionAdapter(Context context, ArrayList<Position> positions) {
        super(context, R.layout.position, positions);
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        final Position currentPosition = getItem(position);
        PositionViewHolder positionViewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.position, parent, false);

            positionViewHolder = new PositionViewHolder();
            positionViewHolder.positionButton = convertView.findViewById(R.id.positionButton);
            positionViewHolder.positionButton.setText(currentPosition.getSequenceNumber() + "");

            convertView.setTag(positionViewHolder);
        }
        else {
            positionViewHolder = (PositionViewHolder) convertView.getTag();

            NodeClient node = currentPosition.getAssignedNode();
            if (node != null) {
                positionViewHolder.positionButton.setText(node.getId());
            } else {
                positionViewHolder.positionButton.setText(currentPosition.getSequenceNumber() + "");
            }
        }

        return convertView;
    }
}
