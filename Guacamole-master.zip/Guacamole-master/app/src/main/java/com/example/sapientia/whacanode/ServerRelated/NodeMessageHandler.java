package com.example.sapientia.whacanode.ServerRelated;

import com.example.sapientia.whacanode.ServerRelated.NodeClient;

public interface NodeMessageHandler {
    void handleMessage(NodeClient node, String message);
}
