package com.example.sapientia.whacanode.Models;

public class Statistic {
    public String playerName;
    public String exerciseName;
    private int mistakes;
    private double reaction_avarage;
    private double nrOfReactions;
    private double reaction_min = Double.MAX_VALUE;
    private double reaction_max = Double.MIN_VALUE;

    public double getReaction_avarage() {
        return reaction_avarage / nrOfReactions;
    }

    public double getReaction_max() {
        return reaction_max;
    }

    public double getReaction_min() {
        return reaction_min;
    }

    public int getMistakes() {
        return mistakes;
    }

    public void addReaction(double reaction) {
        if (reaction == -1) {
            mistakes++;
        } else {
            reaction_avarage += reaction;
            nrOfReactions++;
            if (reaction < reaction_min) {
                reaction_min = reaction;
            }
            if (reaction > reaction_max) {
                reaction_max = reaction;
            }
        }
    }
}
