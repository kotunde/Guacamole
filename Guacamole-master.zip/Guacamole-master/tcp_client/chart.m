M = csvread("meres2szurt.txt")';
n = size(M);
x = 1:1:75;
plot(x, M(2, :) / 1000000);
title('Reaction times for random sequence');
xlabel("Measurement index");
ylabel("Reaction time(seconds)");